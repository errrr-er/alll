　シナリオ名【きっと月だけがしるオーバード】
　
　◆内容物
　添付ファイル
　・シナリオ本文（縦書きPDF・テキスト）
　・投げるだけ部屋（room.zip）

　画像
　・トレーラー（４枚）
　・ＡＰＮＧ素材（３枚）
　・ロゴ（１枚）
　・ＮＰＣ画像（１枚）
　
　◆注意事項
　・神話生物対する独自解釈を含みます。
　・トレーラーや投げるだけ部屋をセッションと関係のない場で使用することはご遠慮ください。
　・シナリオの二次配布、画像の無断転載は厳禁です。
　・ワンクッションを置かないネタバレ発言はご遠慮ください。 
　・都合により、突然配布を停止する可能性もございます。ダウンロードいただいている方はその後自由に遊んでいただいて問題ありません。

　◆権利表示
　本作は、「 株式会社アークライト  」及び「株式会社KADOKAWA」が権利を有する『クトゥルフ神話TRPG』の二次創作物です。

　Call of Cthulhu is copyright ©1981, 2015, 2019 by Chaosium Inc. ;all rights reserved. Arranged by Arclight Inc.
　Call of Cthulhu is a registered trademark of Chaosium Inc.
　PUBLISHED BY KADOKAWA CORPORATION　「クトゥルフ神話TRPG」