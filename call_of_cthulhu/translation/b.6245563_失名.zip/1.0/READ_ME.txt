在进行剧情游戏时，KP和PL都必须携带规则书或指定的补充材料。
由于某些情况，可能会突然停止发布。
已下载的玩家可以在之后自由进行游玩。

◆以下行为严格禁止：
- 在与模组无关的场合使用内容物
- 没有预警的剧透发言
- 模组的二次配布、图片的未经授权转载
- 对封面图进行临摹
- 将封面图拆解并作为素材使用
- 在没有提供logo的模组中，剪切封面中的logo并使用

此外，请务必查看BOOTH页面的概要以及ccf素材中附带的注意事项。

ハッピーエンド主義
銀食器
@shiawaseTRPG

◆権利表示
本作は、「 株式会社アークライト  」及び「株式会社KADOKAWA」が権利を有する『クトゥルフ神話TRPG』の二次創作物です。

Call of Cthulhu is copyright ©1981, 2015, 2019 by Chaosium Inc. ;all rights reserved. Arranged by Arclight Inc.
Call of Cthulhu is a registered trademark of Chaosium Inc.
PUBLISHED BY KADOKAWA CORPORATION　「クトゥルフ神話TRPG」