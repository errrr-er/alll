　シナリオを遊ぶ際は、ＫＰ・ＰＬともに必ずルールブックや指定のサプリを所持してください。
　都合により、突然配布を停止する可能性もございます。ダウンロードいただいている方はその後自由に遊んでいただいて問題ありません。
　

　
　◆以下厳禁
　・内容物をセッションと関係のない場で使用する
　・ワンクッションを置かないネタバレ発言
　・シナリオの二次配布、画像の無断転載
　・トレーラーイラストのトレース
　・トレーラー画像をバラして素材として利用する
　・ロゴ配布されていないシナリオで、トレーラーからロゴを切り抜いて使用する
　
　その他、BOOTHの概要や部屋素材につけた注意事項を必ず確認してください。

　
　サークル名：ハッピーエンド主義
　作者：銀食器
　Ｘアカウント：@shiawaseTRPG
　

　◆権利表示
　本作は、「 株式会社アークライト  」及び「株式会社KADOKAWA」が権利を有する『クトゥルフ神話TRPG』の二次創作物です。

　Call of Cthulhu is copyright ©1981, 2015, 2019 by Chaosium Inc. ;all rights reserved. Arranged by Arclight Inc.
　Call of Cthulhu is a registered trademark of Chaosium Inc.
　PUBLISHED BY KADOKAWA CORPORATION　「クトゥルフ神話TRPG」