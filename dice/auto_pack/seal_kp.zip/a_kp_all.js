// ==UserScript==
// @name         KP群汇总
// @author       3987681449
// @version      1.0.0
// @description  (.kp)有问题可进群2150284119联系
// @timestamp    1794089334
// 2025-05-11 16:49:17
// @license      Apache-2
// @homepageURL  https://jihulab.com/luj13014/alll
// @updateUrl    https://gh-proxy.org/https://raw.githubusercontent.com/errrr-er/alll/refs/heads/main/dice/sealpack/kp_all/scripts/a_kp_all.js
// ==/UserScript==

let ext = seal.ext.find('KP群汇总');
if (!ext) {
  ext = seal.ext.new('KP群汇总', 'er', '1.0.0');
  seal.ext.register(ext);
}

// 群号映射表(action)
const groupMap = {
    "1920拍案惊奇": {groupNumber:"686159620"},
    "ABO同工同酬": {groupNumber:"991822168*下载\n991872893*KP"},
    "ABS": {groupNumber:"941349942",aliases:["全蓝综合征"]},
    "AIB": {groupNumber:"112077093"},
    "Alset": {groupNumber:"801933013"},
    "Antinomy": {groupNumber:"101476385"},
    "Ars": {groupNumber:"874854945",aliases:["Magica"]},
    "BASH": {groupNumber:"774156947",aliases:["燃星"]},
    "BG/GB": {groupNumber:"1049810156\n536347944*仅BG\n602634416*仅GB(主coj)"},
    "brp": {groupNumber:"788438516"},
    "Bubble on Stage": {groupNumber:"734220119"},
    "c0j从零开始的异世界生活": {groupNumber:"1130508493"},
    "CAIN": {groupNumber:"1030175136"},
    "CandelaObscura": {groupNumber:"1053180006*下载\n1049162012*KP",aliases:["暗烛"]},
    "ccf": {groupNumber:"805511454*搭房\n1060652550*招募"},
    "Crosslayers": {groupNumber:"731449106"},
    "Cry and": {groupNumber:"264641814"},
    "dear-flip-flops": {groupNumber:"345837146",aliases:["dff"]},
    "DiceEasy": {groupNumber:"887482271"},
    "difftruth": {groupNumber:"849680089"},
    "Earthdawn": {groupNumber:"1081610526"},
    "EDIBLE": {groupNumber:"1040546365"},
    "Fate": {groupNumber:"162792989\n963069359*极简\n602145072*黑幕\n905396897*梅林\n535057473*胜率制\n927740897*咕咕",aliases:["圣杯"]},
    "fist": {groupNumber:"830324938"},
    "GinGin": {groupNumber:"1035861353"},
    "GODARCA": {groupNumber:"869783432"},
    "GURPS": {groupNumber:"577412220"},
    "H:tv": {groupNumber:"684526713"},
    "insane": {groupNumber:"650600421"},
    "IQ游行Re：LOAD": {groupNumber:"1062159214"},
    "JK青春大爆炸": {groupNumber:"588263902"},
    "log": {groupNumber:"675664988*存放\n873371415*存放\n985865497*整理\n1072162302*整理"},
    "LUCA": {groupNumber:"1077454734*下载"},
    "magnificas": {groupNumber:"477317221"},
    "moon cell": {groupNumber:"972416799*下载\n817071819*KP"},
    "MTG世设": {groupNumber:"1043664376"},
    "m大随机杀人事件": {groupNumber:"1079465494*下载\n548428936*KP"},
    "NewEgg": {groupNumber:"993062536"},
    "nobody": {groupNumber:"694908547",aliases:["nbd"]},
    "one way straight": {groupNumber:"978645254*下载"},
    "Over kill the festival": {groupNumber:"https://seesaawiki.jp/trpgyarouzu/d/Over%20kill%20the%20festival"},
    "PAC": {groupNumber:"720930120"},
    "pathfinder 2e": {groupNumber:"695214825",aliases:["pf2"]},
    "reaby": {groupNumber:"334767023"},
    "Regnagleppod": {groupNumber:"939930942",aliases:["玻璃人"]},
    "Repeat Actor Me": {groupNumber:"1033308060",aliases:["ram"]},
    "rEpl∀λ": {groupNumber:"1082342542",aliases:["回溯"]},
    "ROP": {groupNumber:"783947110*有作者\n780307937*无作者",aliases:["生丝"]},
    "R∈D - Re:Dawn -": {groupNumber:"859997225",aliases:["R∈D", "Re:Dawn"]},
    "SCP基金会": {groupNumber:"602431810",aliases:["FITF", "Fear in the Foundation"]},
    "Sillage香水屋": {groupNumber:"921302134"},
    "SKT": {groupNumber:"376500876"},
    "Snow Spine": {groupNumber:"1070979351",aliases:["雪脊"]},
    "ssk": {groupNumber:"708231245"},
    "ssss": {groupNumber:"926664565",aliases:["4s"]},
    "Stifle, and with hymn": {groupNumber:"1064285359*下载\n1062672838*KP"},
    "The Moist Star": {groupNumber:"1035170762*下载"},
    "the name": {groupNumber:"324809275*下载",aliases:["遗书"]},
    "TRPG营地": {groupNumber:"#腾讯频道：paotuanyingdi"},
    "trpg规则怪谈": {groupNumber:"588164179"},
    "U name it": {groupNumber:"1072212301"},
    "vamp": {groupNumber:"553675094"},
    "ventangle": {groupNumber:"915670503"},
    "VEЯ": {groupNumber:"798805482",aliases:["ver"]},
    "VHS恐怖录像带": {groupNumber:"1046030424"},
    "VirtuaLive": {groupNumber:"664998654*下载"},
    "void": {groupNumber:"1170037255"},
    "wts": {groupNumber:"763188284"},
    "WWRPG": {groupNumber:"818401752",aliases:["Wizarding World"]},
    "X休止": {groupNumber:"623836728"},
    "X告白": {groupNumber:"575451544"},
    "zinki": {groupNumber:"761916849"},
    "一梦": {groupNumber:"431528579*下载+KP",aliases:["血系"]},
    "七大不可思议": {groupNumber:"541345089*KP"},
    "七海": {groupNumber:"795236450",aliases:["航海"]},
    "万人无我": {groupNumber:"929768460",aliases:["wrww"]},
    "万木惊春时": {groupNumber:"371709132"},
    "万能局": {groupNumber:"744931498\n783967451*不含coj"},
    "万象坤舆": {groupNumber:"566101129"},
    "三台风月": {groupNumber:"1084095765"},
    "三国志演技": {groupNumber:"677360997"},
    "三尺之下": {groupNumber:"976406595\n1035721236"},
    "三尺微命": {groupNumber:"1031833569*无作者"},
    "三局两胜": {groupNumber:"208964986*官方"},
    "三角机构": {groupNumber:"1056836484\n585321503"},
    "不死灭灭": {groupNumber:"279755638"},
    "不要占据悲剧的良夜": {groupNumber:"1092780290*下载"},
    "不见蓬山": {groupNumber:"834893891"},
    "不辜马戏团": {groupNumber:"759642443",aliases:["不辜"]},
    "世界树": {groupNumber:"1016727121",aliases:["OVERLOAD"]},
    "东京g": {groupNumber:"201906582"},
    "东京v": {groupNumber:"613821934"},
    "东方快车上的恐怖": {groupNumber:"639753886",aliases:["东快"]},
    "中古战锤": {groupNumber:"649155147",aliases:["wfrp"]},
    "为渡圆寂之都": {groupNumber:"953195114"},
    "为生命献上砂糖、可可、和肉桂粉": {groupNumber:"1037886003*有作者\n817342041*无作者",aliases:["糖可桂", "tkg"]},
    "为谢幕献上祝福的齿轮": {groupNumber:"714364138",aliases:["齿轮"]},
    "举头三尺": {groupNumber:"334821036"},
    "乌洛波洛斯的末日巡演": {groupNumber:"451471718"},
    "乐博睿": {groupNumber:"245808089*官方"},
    "二重身的证迹": {groupNumber:"285230351"},
    "于赤土腹中再会": {groupNumber:"1060512906"},
    "云上仙": {groupNumber:"976215992*KP"},
    "云黑": {groupNumber:"795251459"},
    "亚里斯特拉魔法学院": {groupNumber:"759411294"},
    "京痕雨记": {groupNumber:"496904508*下载"},
    "亮剑": {groupNumber:"1026897898"},
    "亲爱的，我把脑子丢了": {groupNumber:"839027414",aliases:["脑丢", "丢脑"]},
    "人生restart": {groupNumber:"537691966"},
    "人间见闻录": {groupNumber:"921349225*下载"},
    "什么叫做kpc……": {groupNumber:"1079232693*下载",aliases:["春日宴"]},
    "今古空名": {groupNumber:"962147366"},
    "今日晴": {groupNumber:"571731435"},
    "仙人抚顶": {groupNumber:"1056213411"},
    "代号行者": {groupNumber:"433389798"},
    "以太枢纽": {groupNumber:"854266149"},
    "以撒的狂想曲": {groupNumber:"907783672"},
    "伊卡洛斯的忠堰": {groupNumber:"749121463",aliases:["伊卡忠"]},
    "众妙之门": {groupNumber:"3109958989*下载\n785654926*KP\n651350563*KP",aliases:["zmzm"]},
    "伪装者": {groupNumber:"965809145"},
    "似人非人": {groupNumber:"869916259"},
    "你是谁？请支持百日○纪！": {groupNumber:"1057449882"},
    "你的鱼缸里也会倒映出我的脸吧": {groupNumber:"1101358217*下载"},
    "你这什么跑团，你这coj害人不浅啊": {groupNumber:"745155380*下载"},
    "侠界之旅": {groupNumber:"210679492"},
    "侠骨生花": {groupNumber:"617241018"},
    "侦探可有翅膀吗": {groupNumber:"963854131",aliases:["侦探翅"]},
    "便当杀人事件": {groupNumber:"1098707012*下载\n701160953*KP"},
    "信仰都市": {groupNumber:"871704711"},
    "先生": {groupNumber:"1014361521"},
    "克苏鲁的呼唤": {groupNumber:"1103312794*官方\n733157594\n1050056733\n934701317\n965692965\n442320992\n696912430\n\n*<纯女>的相关群聊不在此列，请自行按关键词进行查找",aliases:["coc"]},
    "克苏鲁迷踪": {groupNumber:"780909682\n19859317",aliases:["toc"]},
    "全景敞视主义的陷阱": {groupNumber:"792650936"},
    "全职猎人": {groupNumber:"236140271"},
    "八方旅人": {groupNumber:"549132432"},
    "公若渡河": {groupNumber:"1095875707*下载\n1101528355*KP"},
    "共鸣性怪异": {groupNumber:"903173796\n720345251"},
    "兽与济世之雨": {groupNumber:"1074954896*下载"},
    "内锈": {groupNumber:"1061071715"},
    "再见新世界": {groupNumber:"1004914022*下载\n909369023*KP"},
    "冒充神明的童话": {groupNumber:"1062511494"},
    "写作": {groupNumber:"629998485*魔都\n734417134*纯女\n761666326*纯女coj"},
    "冤缘远怨": {groupNumber:"1033066580*下载"},
    "冰风谷": {groupNumber:"537262507"},
    "凤去台空江自流": {groupNumber:"979768022*下载\n985261346*下载",aliases:["瑰绿的决心", "天地熔金", "人间烟火", "问天地"]},
    "列文菲舍变例": {groupNumber:"1040678581"},
    "别来无恙": {groupNumber:"907810853"},
    "剑世界": {groupNumber:"614559786"},
    "剪月集": {groupNumber:"631939804"},
    "勇者无法拯救世界": {groupNumber:"https://weibo.com/6610227442/5304017647572067*下载"},
    "匕首之心": {groupNumber:"791858682\n583981590\n741973133\n971324974"},
    "化作海上之雨": {groupNumber:"399589228*下载",aliases:["海雨"]},
    "北东路疑案": {groupNumber:"953349303"},
    "北欧奇谭": {groupNumber:"655192271"},
    "十七年蝉": {groupNumber:"237742659"},
    "十六段夜谈": {groupNumber:"938304846"},
    "十支蜡烛": {groupNumber:"936098717"},
    "升平世旧": {groupNumber:"1041314728"},
    "午夜的沙": {groupNumber:"864767076"},
    "卓尔崛起": {groupNumber:"612440945"},
    "博德之门的英雄们": {groupNumber:"1005326913"},
    "卡森德拉的黑色嘉年华": {groupNumber:"297175538",aliases:["卡镇"]},
    "卢埃德街的海鸣": {groupNumber:"972416799*下载",aliases:["性转潜入免女郎俱乐部是认真的吗", "北天的夜行列车"]},
    "卯花腐雨": {groupNumber:"1083939047*下载\n1098370507*有作者",aliases:["mhfy"]},
    "即兴喜剧": {groupNumber:"1023883963"},
    "双人搜查": {groupNumber:"616576634\n708592536"},
    "双头蛇": {groupNumber:"941453461"},
    "双生悲剧": {groupNumber:"1022285434"},
    "双重十字": {groupNumber:"651709429"},
    "变形金刚": {groupNumber:"1051538965"},
    "叙事幻想": {groupNumber:"678355858"},
    "口胡": {groupNumber:"106133577"},
    "后室": {groupNumber:"965315918"},
    "吟游之歌": {groupNumber:"663586886*官方"},
    "听枫馆": {groupNumber:"1047473677*官方\n372088420*仅辐射",aliases:["辐射", "喵影奇谋", "赛博朋克RED"]},
    "吹笛子的海獭": {groupNumber:"468213532"},
    "周边": {groupNumber:"945344459*汇总\n1073238820*交易\n271267478*无料互换",aliases:["谷子"]},
    "呼唤爱的谢幕": {groupNumber:"https://www.dicecho.com/module/657ed2b14ae3570027bdc886*下载\n929268821*KP",aliases:["axm", "爱谢幕"]},
    "命运trpg": {groupNumber:"739814854\n#腾讯频道：su79t2dr02"},
    "命运转轮": {groupNumber:"241837204"},
    "哀歌弥赛亚": {groupNumber:"609355937"},
    "哈欠门": {groupNumber:"631595428"},
    "哑蝉的剖白": {groupNumber:"613231813"},
    "哥谭39:永恒之镜": {groupNumber:"858799831",aliases:["Gotham39: The Mirror Eternal"]},
    "囚人医療部": {groupNumber:"689946642*下载"},
    "四季配送": {groupNumber:"1101946792"},
    "回声岛": {groupNumber:"591639934"},
    "回环物语": {groupNumber:"621551802"},
    "圣土遗梦": {groupNumber:"146415338"},
    "圣诞快乐，玛丽小姐": {groupNumber:"864404671*下载\n1041629808*KP",aliases:["玛丽"]},
    "圣餐": {groupNumber:"659334919"},
    "在黎明到来之前": {groupNumber:"788432874*下载"},
    "地区": {groupNumber:"716242213*上海\n936981574*福建\n46149913*温州\n775753044*青岛\n1055920197*广西\n1055776868*钦州\n855687184*江浙沪\n722890269*呼和浩特\n1106840454*齐齐哈尔\n771840771*山河四省\n751097154*澳大利亚\n\n北京\n118563070\n1079372659*非coc/dnd\n\n沈阳\n254263927\n1101413243",aliases:["面团"]},
    "地图制作": {groupNumber:"https://watabou.itch.io/perilous-shores\n大尺度，区域地图，可商用\nhttps://watabou.itch.io/one-page-dungeon\n随机生成，单层地下城地图，可商用\nhttps://watabou.itch.io/medieval-fantasy-city-generator\n中世纪，城镇地图，可商用\nhttps://probabletrain.itch.io/dungeon-scrawl\n方格地下城，扩展度高，可做多层，遵循cc0协议\nhttps://deepnight.itch.io/tabletop-rpg-map-editor\n房间地图，像素二维，可商用\nhttps://probabletrain.itch.io/city-generator\n随机，现代城市地图，可商用\nhttps://watabou.itch.io/neighbourhood\n彩色城镇地图，可商用\nhttps://watabou.itch.io/village-generator\n村庄地图，可商用\nhttps://wyvernindustries.itch.io/stationgen\n空间站地图，可编辑，付费\nhttps://watabou.itch.io/fantasy-manor\n随机庄园，可商用\nhttps://watabou.itch.io/city-viewer\n3D城市，随机，可商用\nhttps://watabou.itch.io/procgen-mansion\n豪宅、洋馆，随机，可制平面图，定制程度高，可商用\nhttps://chillcash.itch.io/map-generator\n世界地图生成\nhttps://ngreend.itch.io/hexmappy\n六角地图\nhttps://thowsenmedia.itch.io/worldshaper\n支持3D的地图、地形生成\nhttps://playest.itch.io/hextml\n六边形地图制作\nhttps://tortue.itch.io/terraingenerator\n2D地形生成"},
    "地城突击": {groupNumber:"1002876043"},
    "坏公司": {groupNumber:"638653277"},
    "坠入阿弗纳斯": {groupNumber:"223713820"},
    "坤元劫": {groupNumber:"954535020*下载\n862291565*KP",aliases:["kyj"]},
    "塔罗战记": {groupNumber:"930038802"},
    "墨拉亚的羊群": {groupNumber:"671767814*下载"},
    "复制人的葬列": {groupNumber:"958270654"},
    "夕妖晚谣": {groupNumber:"746417676"},
    "多灾多难梵达林": {groupNumber:"570879430",aliases:["矿坑", "冰塔峰", "风暴君王", "风骸岛"]},
    "多规则群": {groupNumber:"554797188\n337270379\n691707475\n630985774\n877823625*主武侠"},
    "大德歌": {groupNumber:"1092691584"},
    "大道纪年": {groupNumber:"932560339*KP\nhttps://pan.baidu.com/share/init?surl=iNbFg3DD13ChPHPKc1035A&pwd=NZBY"},
    "天下第一刀": {groupNumber:"369645861*无作者"},
    "天不遂人愿": {groupNumber:"985964031*下载\n1124497024*KP\n1107964401*官方"},
    "天启伏诛": {groupNumber:"1075156103*下载\n1093079819*有作者"},
    "天启劫火": {groupNumber:"1059690417"},
    "天命所归": {groupNumber:"875210475"},
    "天地一灯": {groupNumber:"974274779"},
    "天师": {groupNumber:"587952595*下载"},
    "天才剑修▆▆法则": {groupNumber:"1095791459*下载"},
    "天枢高中之青春是达芬！": {groupNumber:"861967407*下载"},
    "天椎谶纬": {groupNumber:"656026457"},
    "天衍剧组": {groupNumber:"637230426"},
    "天衍江湖录": {groupNumber:"463467776"},
    "天衍纪年": {groupNumber:"666391763\n675869524",aliases:["tyjn"]},
    "太岁": {groupNumber:"615878940*下载\n703542083*KP"},
    "太空海怪": {groupNumber:"694587685"},
    "失序症": {groupNumber:"850384014"},
    "失忆后有了三个恋人": {groupNumber:"562613533"},
    "奇异医科": {groupNumber:"1033132363*下载",series:["放学后团研社"]},
    "奇异恩典": {groupNumber:"1040690307"},
    "奈面": {groupNumber:"933493427",aliases:["奈亚拉托提普的面具"]},
    "奥德修斯的归还有": {groupNumber:"1103072276*有作者\n1130642817*无作者"},
    "如此渺小的橡果": {groupNumber:"827206593*下载\n264764228*KP"},
    "妄想症": {groupNumber:"278636978",aliases:["赛博朋克题材"]},
    "孤岛恋综": {groupNumber:"932315790*下载"},
    "孤灯弃城": {groupNumber:"877858567"},
    "宝可梦": {groupNumber:"942569081"},
    "寂静挽歌": {groupNumber:"1084909160"},
    "寻仙I神仙索": {groupNumber:"746673328*下载",aliases:["寻仙II观音土"]},
    "寻龙": {groupNumber:"1064363228*下载\n1080240157*无作者"},
    "封君封臣": {groupNumber:"204956184"},
    "将潮水遗忘之物也一并收下吧": {groupNumber:"904394289*下载"},
    "将钟表拨回茶杯摔破之前": {groupNumber:"651922911*下载"},
    "小众规则汇总": {groupNumber:"https://docs.qq.com/sheet/DT2pkUkpkbGVWWVB5\n*此文档非插件作者负责，文档相关问题请进文档内提到的相关群聊(677691116)\n\n*本插件同步至2026-06-01的文档数据"},
    "小众规则综合": {groupNumber:"945728295"},
    "小马宝莉": {groupNumber:"851487172"},
    "少恶世界": {groupNumber:"849810896\n少恶世界+蚀甚",aliases:["蚀甚"]},
    "尸体电台": {groupNumber:"2665895669"},
    "展会": {groupNumber:"134738234*北京RP\n748588753*上海PC\n753085340*幻想共振\n524602166*GTS&VR"},
    "属于吾等的安乐之所": {groupNumber:"826771926"},
    "山中无盈月": {groupNumber:"1098856853*下载\n1101323055*KP"},
    "山歌唤梦": {groupNumber:"850176131*下载\n972586937*KP"},
    "山海·启程": {groupNumber:"1044403168"},
    "山羊之歌未曾唱响": {groupNumber:"1054748794",aliases:["白鸟之歌鸣唱之时", "羊歌", "鸟歌"]},
    "崎蜀藏观音": {groupNumber:"652844613"},
    "崩铁": {groupNumber:"836574979"},
    "左川之国失落谭": {groupNumber:"770779991"},
    "巨龙迷城": {groupNumber:"1057192428"},
    "巫光之外的荒野": {groupNumber:"594209337"},
    "帕瑞卡颂马戏团": {groupNumber:"760671074"},
    "帷灯匣剑": {groupNumber:"850934230*下载\n984247613*KP"},
    "常夜国": {groupNumber:"769437181*骑士谭+舞跃剧\n199420568*舞跃剧",aliases:["真祖红舞曲"]},
    "幕临": {groupNumber:"160438930"},
    "平庸之恶": {groupNumber:"1048257881*下载\n849554363*KP"},
    "幸福与心动的民谣": {groupNumber:"1036780211"},
    "幽世常世的满天下": {groupNumber:"749173986"},
    "幽灵记录": {groupNumber:"1053204546*下载"},
    "幽诱,于指尖燃起": {groupNumber:"978331360"},
    "应天劫": {groupNumber:"231734390*下载\n2811466327*墙"},
    "废土残生": {groupNumber:"626636740"},
    "废案重组": {groupNumber:"857972438"},
    "废楼怪谈": {groupNumber:"563488359"},
    "庭师所吟为何物": {groupNumber:"656434498",aliases:["庭师"]},
    "开放桌": {groupNumber:"438108350*官方"},
    "异教徒": {groupNumber:"810537153",aliases:["风暴岛"]},
    "异界使之旅": {groupNumber:"746325468"},
    "异神成渊": {groupNumber:"916464615"},
    "异端蛇说": {groupNumber:"572778180"},
    "异能儿童管理机构": {groupNumber:"786412774*下载\n817252450*KP"},
    "异能警察不是什么英雄": {groupNumber:"873824063"},
    "弃约社会": {groupNumber:"972643133*下载\n916122224*KP"},
    "弥勒佛": {groupNumber:"316394180\n830571107",aliases:["Mythras"]},
    "弥岛刃谭": {groupNumber:"1105848179*通知(20041024)\nhttps://kuizy.net/analysis/30613"},
    "当代电影": {groupNumber:"1023220397"},
    "当合欢宗遇上无情道": {groupNumber:"1048818266*下载\n736394722*下载\n112452157*KP",aliases:["合欢宗"]},
    "彼都": {groupNumber:"952122633"},
    "往明": {groupNumber:"1039171010*下载\n1039312225*KP"},
    "德拉肯海姆之墟": {groupNumber:"856703297"},
    "心愿寄于清夏": {groupNumber:"599817890"},
    "心病救赎": {groupNumber:"573269302"},
    "心脏": {groupNumber:"883465896*无全译本"},
    "心跳": {groupNumber:"1047506640"},
    "忍神": {groupNumber:"750542419\n866506419\n750542354"},
    "忍者杀手": {groupNumber:"1141101336+1056029096"},
    "快刀乱魔": {groupNumber:"238285939"},
    "快刀乱魔贰": {groupNumber:"417453795",aliases:["快刀2"]},
    "怀抱秘密的妻子": {groupNumber:"1054698251",aliases:["ヒミツの奥様"]},
    "性少数": {groupNumber:"1040151106"},
    "性福安心委員会": {groupNumber:"https://koufukuanshiniinkai.wixsite.com/trpg",aliases:["性福安心委员会"]},
    "怪物们与邪典仙境": {groupNumber:"592577986",aliases:["鞋垫"]},
    "怪胎": {groupNumber:"639870851"},
    "恋爱党政": {groupNumber:"263776524"},
    "恐怖墓穴": {groupNumber:"329392650"},
    "恰故人归": {groupNumber:"607468653*KP"},
    "恶辣": {groupNumber:"620832218"},
    "愚者的祈雨": {groupNumber:"1062832797"},
    "戏法师的感知": {groupNumber:"144919125"},
    "我的同桌才没有那么可爱": {groupNumber:"1076334102*下载\n1022387123*下载\n1085169094*下载\n980074681*KP"},
    "战争神谕": {groupNumber:"413947504"},
    "战锤40k": {groupNumber:"540375694"},
    "战锤魂缚": {groupNumber:"945548706"},
    "抑或地位未定": {groupNumber:"1041670093",aliases:["所属不明"]},
    "抽刀": {groupNumber:"1057856638"},
    "拉普拉斯": {groupNumber:"1050071534"},
    "拜昆仑": {groupNumber:"248817589"},
    "挽歌": {groupNumber:"160770510"},
    "掌中雪": {groupNumber:"860685448*下载"},
    "掷骰演出": {groupNumber:"1090720849*下载"},
    "提灯铁鼠": {groupNumber:"882067951"},
    "摇曳群青": {groupNumber:"513712312"},
    "撞邪": {groupNumber:"415568723"},
    "故障乱码文本": {groupNumber:"https://tw.piliapp.com/cool-text/zalgo-text/"},
    "教师A的终焉": {groupNumber:"966092780*下载",aliases:["7-Day Cricle", "七日之轮"]},
    "文字乱码制作": {groupNumber:"https://anytexteditor.com/cn/cursed-text-generator"},
    "文手": {groupNumber:"512451066"},
    "斩我": {groupNumber:"776965370"},
    "斫夜": {groupNumber:"220150371*下载",aliases:["王龙告"]},
    "断头爱丽丝": {groupNumber:"1073575754"},
    "断梦行": {groupNumber:"1051020748*PL\n1029592193*KP"},
    "斯坦哈德": {groupNumber:"929033286"},
    "斯特拉德的诅咒": {groupNumber:"824773454"},
    "斯翠海文": {groupNumber:"838512466"},
    "新世界": {groupNumber:"943798191"},
    "新矿坑": {groupNumber:"894191386",aliases:["方尖碑"]},
    "旅行者": {groupNumber:"1080491850"},
    "旅馆的捕食者": {groupNumber:"884768719",aliases:["旅捕", "吕布"]},
    "无为有处有还无": {groupNumber:"768399206",aliases:["wwyc"]},
    "无何有乡的Apoptosis": {groupNumber:"1126534576"},
    "无名集": {groupNumber:"663572400\n885775749"},
    "无声二重唱": {groupNumber:"965715801\n634173971"},
    "无尽阶梯": {groupNumber:"923944293"},
    "无罪之歌": {groupNumber:"1018018649*下载"},
    "无限流": {groupNumber:"301122594*星光\n459786188*幻剑侠刀139\n838432541*类无限\n876623982\n756711275"},
    "日夜行人": {groupNumber:"1042210871*下载\n238797418*KP\n977084429*桌宠\n人员档案：https://h5.qzone.qq.com/ugc/share/?sharetag=ffb0142c%2D846d%2D11f1%2Dbf06%2D525400694753&loginfrom=4&jumptoqzone=1&feed_action_domain_type=1&banner_type=0&subtype=&ciphertext=&blog_photo=&g=84&res_uin=260845973&cellid=95318c0fce294f6a00a20b00&subid=&bp1=&bp2=&bp7=&appid=311&g_f=2000000103",aliases:["ryxr", "桌宠"]},
    "日系交流": {groupNumber:"304288183"},
    "时差": {groupNumber:"602634416*欧洲(coj向)\n1054398710*欧美\n\n*<纯女>、<地区>的相关群聊不在此列，请自行按关键词进行查找"},
    "明日方舟TRPG": {groupNumber:"812610777"},
    "明日方舟骰群": {groupNumber:"786166224"},
    "明港市灵异调查组": {groupNumber:"970189117*同好交流"},
    "明镜，仿佛可以斩断春天": {groupNumber:"921034670",aliases:["明镜斩春", "mjzc"]},
    "星升": {groupNumber:"872362745"},
    "星海孤舟": {groupNumber:"657774576*下载"},
    "星海迷城": {groupNumber:"719566794"},
    "星钥次元": {groupNumber:"600408617"},
    "星陨": {groupNumber:"721754031"},
    "春花秋月": {groupNumber:"813932679"},
    "是白纸吗": {groupNumber:"725116701"},
    "显微镜": {groupNumber:"970125146"},
    "晨钟旧事": {groupNumber:"655068229*下载",aliases:["沽上潮生来", "大难临头"]},
    "智人TV": {groupNumber:"1060564003"},
    "暗兽诡剧": {groupNumber:"323902997"},
    "暗夜刀锋": {groupNumber:"854273885"},
    "暗影狂奔": {groupNumber:"201635360"},
    "暗日狂飙": {groupNumber:"1105012753"},
    "暗河": {groupNumber:"1031974789"},
    "暗金": {groupNumber:"666715873"},
    "最后的祝福": {groupNumber:"1005831724*下载"},
    "最后的黄金唱片": {groupNumber:"633374415"},
    "最终物语": {groupNumber:"490912280\n557490083\n981348617"},
    "月山卦辞": {groupNumber:"579691782"},
    "月背迷踪": {groupNumber:"1037660739*下载"},
    "月色真美": {groupNumber:"727102724"},
    "月蜂": {groupNumber:"110208332"},
    "月计": {groupNumber:"639082037\n765965290\n702203298\n#腾讯频道：pd31381795"},
    "朔月笔谈": {groupNumber:"825664784"},
    "望君长留": {groupNumber:"700583235"},
    "木马&短刀": {groupNumber:"873593450*有作者\n564501697*无作者"},
    "未交予的落白": {groupNumber:"1007853163"},
    "未命名参数": {groupNumber:"994367663"},
    "未命名的路": {groupNumber:"1051535084*下载"},
    "未完生": {groupNumber:"#腾讯频道：ny40y57197*下载",series:["晶楼的侍从", "红线啊、快告诉我这是骗人的！", "教室之数，与尸等同"]},
    "末日剑湾": {groupNumber:"812018837",aliases:["维克那的崛起", "维克那的陨落"]},
    "本周主打怪": {groupNumber:"541036527"},
    "机魔少女": {groupNumber:"1042635824"},
    "来到这里的你们放弃希望吧": {groupNumber:"1047069694*KP",aliases:["十二字"]},
    "東京滅亡1999": {groupNumber:"544212628"},
    "极乐颂歌": {groupNumber:"701200710*下载\n967165493*KP"},
    "极地追凶": {groupNumber:"1057328944*下载"},
    "枪骑兵": {groupNumber:"702215091",aliases:["机甲"]},
    "枭熊": {groupNumber:"1033434555"},
    "柏拉图的余谈": {groupNumber:"574918635"},
    "染色空白卡": {groupNumber:"657347350"},
    "查理九世": {groupNumber:"439899070"},
    "树不子英雄传": {groupNumber:"960918320",aliases:["RWBY"]},
    "格罗安萨": {groupNumber:"678247843"},
    "梦里百花深处": {groupNumber:"490454774",aliases:["梦花深"]},
    "棉花不谢": {groupNumber:"1038645659"},
    "模组存放": {groupNumber:"100519094*coc\n530070122*coj"},
    "模组拼车": {groupNumber:"686079835\n983412936",aliases:["私翻"]},
    "欲望之箱": {groupNumber:"739976718"},
    "歌味觉死": {groupNumber:"616756545",aliases:["路易斯安那系列", "畅梦人", "淤泥之花与空心石"]},
    "正义之屎": {groupNumber:"1018334937"},
    "正伪的ideal": {groupNumber:"667098598"},
    "此夜不可离": {groupNumber:"522206940*下载"},
    "武侠克苏鲁": {groupNumber:"524086123",aliases:["woc"]},
    "歪曲之月": {groupNumber:"339403801",aliases:["诡月奇谭"]},
    "死刑执行": {groupNumber:"830833837"},
    "死神的圣域": {groupNumber:"1028029280"},
    "死者的顿足舞": {groupNumber:"1081620177"},
    "残败桃源": {groupNumber:"2154036156"},
    "毁灭亲王": {groupNumber:"882887120",aliases:["POTA"]},
    "母舰": {groupNumber:"1055610593"},
    "永7": {groupNumber:"1092736604"},
    "永夜后日谈": {groupNumber:"710242752\n429107780\n795236450\n1053451040",aliases:["永远的后日谈"]},
    "永虹灰归的Polis": {groupNumber:"696523899"},
    "求不得": {groupNumber:"887012952"},
    "求我": {groupNumber:"338494770*下载\n979194858*下载\n978495486*KP"},
    "求道": {groupNumber:"983418886"},
    "汲水": {groupNumber:"1014352186*下载"},
    "沧渺山": {groupNumber:"855215735",aliases:["cms"]},
    "油盐不进": {groupNumber:"575319883"},
    "沼泽人": {groupNumber:"913354882"},
    "泛界旅者": {groupNumber:"375452673"},
    "波子汽水": {groupNumber:"562672318"},
    "洪荒异闻录": {groupNumber:"932598564"},
    "活神之手": {groupNumber:"1075504939"},
    "流水线心脏": {groupNumber:"793350464",aliases:["流心"]},
    "流浪武士": {groupNumber:"994791183*下载"},
    "浮尘寻仙箓": {groupNumber:"640321978"},
    "浮生安梦": {groupNumber:"881234029"},
    "海·在遗忘之前的晴天": {groupNumber:"710881226",aliases:["晴天"]},
    "海国战役设定集": {groupNumber:"567135881",aliases:["海国图志(dnd扩展)"]},
    "海盗之宴": {groupNumber:"1062169852"},
    "海盗啊海盗": {groupNumber:"928270526"},
    "海龟汤": {groupNumber:"295820752"},
    "深眠雾梦": {groupNumber:"523093958"},
    "清平乐": {groupNumber:"814959956"},
    "渡仙劫": {groupNumber:"634208409"},
    "渡春风": {groupNumber:"199382863",aliases:["dcf", "蛋炒饭"]},
    "游侠豪据": {groupNumber:"663081001"},
    "游龙之年": {groupNumber:"693371984"},
    "湮灭之墓": {groupNumber:"868114556"},
    "溟渊的呼唤": {groupNumber:"431242151",aliases:["艾桑椎亚", "冥渊"]},
    "漂泊之徒": {groupNumber:"1097331960"},
    "演绎&本我": {groupNumber:"583290817",aliases:["yybw"]},
    "漫画英雄": {groupNumber:"488705340"},
    "潘德拉贡": {groupNumber:"836896713"},
    "潜务代理": {groupNumber:"657764329"},
    "潮信来民间": {groupNumber:"278722580"},
    "烁玉流金": {groupNumber:"732502555"},
    "烛堡": {groupNumber:"467303448"},
    "焚天之战": {groupNumber:"1065925723"},
    "燃烧的星辰": {groupNumber:"1049443592"},
    "燃花": {groupNumber:"795081215"},
    "犹格索托斯之影": {groupNumber:"579586813"},
    "狂野世界": {groupNumber:"1095331964"},
    "狐鸣于白雪、狸击腹冰霰": {groupNumber:"1043393781*下载"},
    "狩魂者": {groupNumber:"579621236*官方\n1027976807*官方",aliases:["鬼喊捉鬼"]},
    "狩龙者工作室": {groupNumber:"1065133665\n\n*不知道官还是非官所以没标，有清楚的可以进2150284119群反馈"},
    "狼藉夜行": {groupNumber:"779021829"},
    "猎魔人": {groupNumber:"733953487"},
    "猩红文档": {groupNumber:"159022627"},
    "猫寿司": {groupNumber:"831331659"},
    "猫牧师": {groupNumber:"723434960"},
    "玉台新薤": {groupNumber:"881091572*交流\n439862498*KP"},
    "王之褴褛": {groupNumber:"1078850322"},
    "玛珈的摇篮": {groupNumber:"980800467"},
    "生不逢时": {groupNumber:"829092202",aliases:["雪中形骸"]},
    "生离": {groupNumber:"1061116172"},
    "电子悖论失乐园": {groupNumber:"995398768*下载\n1033563821*KP",aliases:["失乐园", "电子"]},
    "町葬屋怪异谭": {groupNumber:"174136022"},
    "画手": {groupNumber:"1014072522\n714835517"},
    "畜牲道": {groupNumber:"738570884"},
    "疯法师的地城": {groupNumber:"1025248586"},
    "白影": {groupNumber:"738434404*下载\n825032832*KP"},
    "白玉风会录": {groupNumber:"942449479"},
    "盐沼幽魂": {groupNumber:"926412005"},
    "相关多规则": {groupNumber:"1033893591*猫咪\n908267691*怪谈\n748333008*恐怖"},
    "相约98": {groupNumber:"542398417"},
    "石榴": {groupNumber:"1063443035*下载"},
    "祀蛇": {groupNumber:"970244097*下载\n1108845394*KP"},
    "祈舞醒梦": {groupNumber:"1104143844*下载\n1101711435*KP"},
    "神明起舞之日": {groupNumber:"494739702*下载+KP"},
    "神星落乐": {groupNumber:"831229728"},
    "神曲": {groupNumber:"1059465045"},
    "神椿市": {groupNumber:"377098415"},
    "神海羁旅": {groupNumber:"1047203658*官方"},
    "神秘博士": {groupNumber:"862845373"},
    "神话时代": {groupNumber:"316394180*无全译本"},
    "神谕引擎": {groupNumber:"883017168",aliases:["寄生之血"]},
    "祭日颂": {groupNumber:"717598559"},
    "祸不单行": {groupNumber:"1006307638"},
    "秋永录": {groupNumber:"922420972\n712714985",aliases:["qyl"]},
    "秋鬼": {groupNumber:"1095696359*下载"},
    "空箱间": {groupNumber:"858801418*下载\n1044331385*KP"},
    "穿插、跳跃、结束，你与我的日常": {groupNumber:"1085073731\n1097464299"},
    "第三螺旋灰海": {groupNumber:"794319060"},
    "索斯安普顿最后的舞会": {groupNumber:"1043850915"},
    "繁星物语": {groupNumber:"1015603739",aliases:["STARLIGHT"]},
    "纯dm": {groupNumber:"421678315"},
    "纯女": {groupNumber:"coc\n947095759\n797863427\n923952181\n770689154\n1061755248*+绿色三角洲\n\ndnd\n560604565\n960874614\n780528057\n1021578589\n\ncoc+dnd\n869660310\n1016631080\n1057887916*北美洲时差\n609993185*限21+无限流"},
    "纯阳轶事": {groupNumber:"977656290"},
    "细胞复位": {groupNumber:"892835680"},
    "终焉之歌为谁而唱": {groupNumber:"272502055"},
    "绝对励弩": {groupNumber:"1079402848"},
    "继续工作直到毁灭": {groupNumber:"822840569"},
    "维克那毁灭前夕": {groupNumber:"1045993659"},
    "绿月": {groupNumber:"1064264349*下载"},
    "绿色三角洲": {groupNumber:"623759380\n984765632\n253302384\n1061755248",aliases:["dg"]},
    "缉邪司": {groupNumber:"884145991*下载\n876339982*KP",aliases:["jxs"]},
    "缘因何为": {groupNumber:"656621118*下载"},
    "缝春": {groupNumber:"798106857"},
    "罗丝妮": {groupNumber:"518059121*官方",aliases:["灵魂迷雾"]},
    "罗小黑": {groupNumber:"687753523",aliases:["妖灵会馆"]},
    "罗德之妻": {groupNumber:"1059167029"},
    "美妙天堂": {groupNumber:"633326744"},
    "群鸦聚处是极彩": {groupNumber:"619943167",aliases:["极彩色", "无彩色"],series:["群鸦聚处是无彩"]},
    "羽湮": {groupNumber:"376904721*下载"},
    "翠色的光与影": {groupNumber:"1081639467"},
    "翻译": {groupNumber:"1073856681\n1053204546\n972416799\n377896614\n1040799893\n#腾讯频道：pd59993369\n1033917987\n1043393781\n872345826\n1061035045\n220150371*韩模\n#腾讯频道：ny40y57197\n1104565404\n211761949"},
    "耀光城": {groupNumber:"728536185"},
    "老天对我不公": {groupNumber:"1053162150*下载"},
    "老派要典": {groupNumber:"716289444"},
    "肥皂学校": {groupNumber:"980188286",aliases:["肥皂", "皂校"]},
    "脓堕": {groupNumber:"183186533",aliases:["nd"]},
    "致埃尔维斯": {groupNumber:"943134871*下载\n1055649275*下载\n1104377643*KP"},
    "致我不灭的": {groupNumber:"1073548076*下载\n1077901406*KP"},
    "致让我们死去活来仍然热爱的冰上的一切": {groupNumber:"1087789609*下载\n1087899806*KP",aliases:["滑冰"]},
    "舞榭歌台": {groupNumber:"147313715"},
    "色之形": {groupNumber:"867848385*下载\n961190856*KP"},
    "艺术是死": {groupNumber:"902444229",aliases:["1444", "ysss"]},
    "芝加哥之王": {groupNumber:"559366167"},
    "花&葬送者": {groupNumber:"555632875\n106559548",aliases:["花葬"]},
    "花盗人之恋": {groupNumber:"966519249"},
    "花联物语": {groupNumber:"716402709"},
    "苦昼短": {groupNumber:"139406002*下载\n1046515083*下载\n422463860*KP"},
    "荆山祭": {groupNumber:"1092255456*下载"},
    "荣光不灭": {groupNumber:"636253864*下载(荣光不灭+陛下您这后宫不对劲)\n1103423594*荣光不灭KP",series:["陛下您这后宫不对劲"]},
    "莫索里哀的圣职者": {groupNumber:"435690433",aliases:["msla"]},
    "萨里希斯之光": {groupNumber:"473373105\n930332469"},
    "落石": {groupNumber:"603178528"},
    "蒙娜丽莎杀死格尔尼卡": {groupNumber:"580704423"},
    "蓬莱有龙": {groupNumber:"1101230234"},
    "蕾忍宗": {groupNumber:"1037073273"},
    "虚白馆·无人生还": {groupNumber:"1085269036"},
    "虚诞的毁灭": {groupNumber:"1046244155"},
    "蛙徒的祭典": {groupNumber:"655890716",aliases:["蛙祭", "挖机"]},
    "螺旋旅人发问道": {groupNumber:"859933056"},
    "蟑螂启示录": {groupNumber:"957865225"},
    "血色豪门": {groupNumber:"979353223"},
    "行行重": {groupNumber:"720893039",aliases:["xxc"]},
    "衔尾蛇启示录": {groupNumber:"439061754*有作者"},
    "裗浳": {groupNumber:"#腾讯频道：pd59993369*下载",series:["只有月亮知道的黎明之歌", "莱拉", "致、亲爱的「你」", "迷明", "木星", "婚礼岛的誓言", "孤独下降", "午夜高中的婴儿", "樱花屋与密之屋", "恐怖村RTA", "深爱", "雪沫颂歌", "新年快乐", "幽灵之舞", "污染区域净化行动", "幻梦境的治愈时刻", "如果是探索者、只需轻轻一按即可赢得一等奖！", "乐园在海底", "午夜之海", "Cross Bord", "21克", "胆颤心惊", "沉睡的月亮歌姬", "佚名", "荆棘之髓", "怪猫馆", "404:Outer Rise", "404:Over Dose", "与狼共舞", "圣诞夜、或是毛绒绒", "人魚之宴", "Blood Hunt & Bio Watch", "警察探索者正常开展搜查", "蓝鲸列车", "蓝鲸列车·驶向起点的鲸鱼", "蓝鲸列车·蓝色列车", "蓝鲸列车·你的21克会杀死我", "SANset Flower's", "革命少女罗丹斯", "U.B.", "FAKERs", "困于23时59分59秒", "在圣诞夜降下的……", "双重世界", "地球猫vs宇宙猫vs猫耳KPC", "极彩色的魔女", "伏于墨火", "皇权之犬、送归神前", "避雨，与一杯咖啡相伴", "星体·石英的去向", "PANOPTICON", "巴别谋杀案", "Thousand Fold", "再见乐园", "Shark the Cthulhu", "Sweet Nightmare", "4MBの侵略者", "集合啦！疯狂之森", "子不语-僵尸-"]},
    "西欧列车杀人事件": {groupNumber:"1065246966"},
    "西比拉": {groupNumber:"669808359"},
    "要继承的遗产里有嫂子怎么办": {groupNumber:"519716458",aliases:["嫂子", "黑乌鸦与不死犬"]},
    "角色桌": {groupNumber:"1078119008*SEGA\n1062894359*彩虹社\n892348859*音乐剧\n1029979195*1999\n862922419*崩铁\n223628950*第五\n1079593722*鬼灭\n\n全职高手\n517535590\n751921932\n#腾讯频道：6btum1huf1\n\n边狱巴士\n302014132\n1049986341\n\n不清楚\n471191700\n363017687",aliases:["语擦"]},
    "讨债鬼": {groupNumber:"973867121*下载(讨债鬼+斩仙槐)\n1065706772*斩仙槐KP",aliases:["星星的葬礼"]},
    "记录的地平线": {groupNumber:"730201662"},
    "论道来处十二楼": {groupNumber:"1060537548*下载"},
    "诛天": {groupNumber:"1090605762*下载\n1034316054*下载"},
    "诡秘之主": {groupNumber:"714267110\n958379633"},
    "语音": {groupNumber:"893711161*主dnd但不限"},
    "请勿入睡": {groupNumber:"619069037*官方\n992859187"},
    "请生下他吧": {groupNumber:"705913038"},
    "谢娘娘点化": {groupNumber:"878626807"},
    "谦卑林": {groupNumber:"941662352"},
    "资料库": {groupNumber:"807277128\n982405257\n1003939226\n923183444*仅日警"},
    "赎罪邮局": {groupNumber:"1064670977"},
    "赛博朋克d20": {groupNumber:"135248365\n283334218"},
    "赛马娘": {groupNumber:"488234672"},
    "赤潮之上": {groupNumber:"1134301078*有作者\n1132035537*无作者"},
    "起承转结": {groupNumber:"1043452922"},
    "跑团禁男吐槽群": {groupNumber:"1098988080"},
    "跨越疯狂山脉": {groupNumber:"1127317088"},
    "跳舞吧，C8！": {groupNumber:"688755089"},
    "边狱巴士同人规则": {groupNumber:"765965290"},
    "还来不见仙": {groupNumber:"590220813*反馈\n984420519*KP"},
    "这一次歌亚请留住TA": {groupNumber:"1098346051*下载\n150936787*有作者\n931981887*无作者",aliases:["歌亚"]},
    "远方呢喃": {groupNumber:"761735153"},
    "远星者": {groupNumber:"820393813"},
    "连海密录": {groupNumber:"926024691"},
    "迷宫王国": {groupNumber:"1043987727"},
    "迷雾之城": {groupNumber:"828730465\n#腾讯频道：1h26o10z09"},
    "追书人": {groupNumber:"942014926"},
    "逃离深渊": {groupNumber:"513100948"},
    "逆命仙途": {groupNumber:"796368505"},
    "逍遥游": {groupNumber:"1083776308"},
    "通衢建灯": {groupNumber:"1046186956*下载"},
    "造物者": {groupNumber:"948914482"},
    "逢春": {groupNumber:"1103341222"},
    "遗香巡游": {groupNumber:"535538005"},
    "邪典:失落神性": {groupNumber:"560510929"},
    "都市:异景": {groupNumber:"1023765025"},
    "重返未来1999": {groupNumber:"219303723"},
    "金酒狂热": {groupNumber:"794429121"},
    "钢之守护神": {groupNumber:"1124826120"},
    "铁爪": {groupNumber:"1072078962"},
    "铁誓": {groupNumber:"487934434"},
    "银蛇": {groupNumber:"1126960695"},
    "镇魂歌": {groupNumber:"709032901"},
    "镜花水月·云上天篇": {groupNumber:"2151061466"},
    "镜语礼赞": {groupNumber:"882672657"},
    "长乐未央": {groupNumber:"934054415*下载\n1029863651*KP"},
    "长兴镇": {groupNumber:"906847246"},
    "长天摘星": {groupNumber:"552342168*无剧透\n595926395*KP"},
    "门扉那端": {groupNumber:"621153022"},
    "问道苍生": {groupNumber:"758798519\n578441689"},
    "阴霾，与消散的你": {groupNumber:"1091169562*下载"},
    "阿斯蒙蒂斯之链coa": {groupNumber:"581885602",aliases:["coa"]},
    "降水志异": {groupNumber:"1046959108"},
    "隐蚀期": {groupNumber:"609897072"},
    "隔离区": {groupNumber:"660198835"},
    "雅努斯式": {groupNumber:"666429307*无剧透\n1061867760*有作者\n750270687*无作者"},
    "雨幕信使": {groupNumber:"1094260426*下载"},
    "雪下残生": {groupNumber:"592418282"},
    "雪与箱庭之梦": {groupNumber:"413941306",aliases:["雪箱"]},
    "雪域下的黄金宝藏": {groupNumber:"527406942*下载\n307758220*KP",aliases:["雪域下的金色宝藏"]},
    "雪山密室": {groupNumber:"901413729"},
    "青春自杀": {groupNumber:"953788807"},
    "靖海难": {groupNumber:"343026343"},
    "非出版短模组": {groupNumber:"1032540988"},
    "非正经修仙": {groupNumber:"645560269"},
    "面包骑士物语": {groupNumber:"951729026"},
    "香槟call可以开发票吗": {groupNumber:"1103396117*下载\n964670473*交流"},
    "高塔之死": {groupNumber:"623768354*战役集",aliases:["告密者"]},
    "高武": {groupNumber:"877823625"},
    "魂夜逃避行": {groupNumber:"1046944266*下载\n1009337218*KP"},
    "魔女与彩爱": {groupNumber:"421693159"},
    "魔女盛宴": {groupNumber:"1031212236"},
    "魔法少女": {groupNumber:"337270379\n598706411\n769291237",aliases:["AMGC"]},
    "魔法少女歌唱死亡": {groupNumber:"868665011"},
    "魔王之影": {groupNumber:"691528948\n305548996",aliases:["SDL"]},
    "魔王大人决定伪装勇者小队讨伐魔族": {groupNumber:"916397240*下载"},
    "魔道书": {groupNumber:"759960406"},
    "魔都模组讨论": {groupNumber:"629998485"},
    "鲸落万物生": {groupNumber:"598393390*下载\n1051952972*KP"},
    "鳞翅": {groupNumber:"963578553"},
    "鸟啼歌": {groupNumber:"1076715464"},
    "鸦阁领域": {groupNumber:"836306797"},
    "黄昏熔解": {groupNumber:"826823719"},
    "黄金宝库": {groupNumber:"546468457"},
    "黎明之盏": {groupNumber:"835468159"},
    "黑暗世界": {groupNumber:"985683120",aliases:["wod", "vtm"]},
    "黑水溪": {groupNumber:"1071548693"},
    "黑石灰": {groupNumber:"1106249203*下载\n1106372822*KP"},
    "齿轮之塔": {groupNumber:"666452898"},
    "龙与地下城": {groupNumber:"5e\n7633611236\n618695186\n1043167230\n601868447\n472247859\n820443183\n549256248\n617262009\n\n4e\n811793816\n\n3r\n655468212\n436399338\n9704777\n\n2e\n671228179\n\n不清楚\n713046227\n144628596\n\n*<纯女>、<语音>的相关群聊不在此列，请自行按关键词进行查找",aliases:["dnd"]},
    "龙台掠雪": {groupNumber:"921013368*官方\n1051220082"},
    "龙后之影": {groupNumber:"595576485",aliases:["龙枪"]},
    "龙后的宝山": {groupNumber:"343516463",aliases:["提亚马特的崛起"]},
    "龙族": {groupNumber:"603211139"},
    "龙港围城": {groupNumber:"1079345156",aliases:["龙门围城"]},
    "龙滨不良": {groupNumber:"597585029",aliases:["lbbl"]},
    "龙王的奥德赛": {groupNumber:"238873224"},
    "龙蛋物语": {groupNumber:"772645004"},
    "龙金劫": {groupNumber:"947826784"}
};

// 反向映射
const groupNumberToNameMap = {};
for (const groupName in groupMap) {
    const groupInfo = groupMap[groupName];
    // 分隔符
    const groupNumbers = groupInfo.groupNumber.split(/[、\n*]/);
    
    groupNumbers.forEach(number => {
        const cleanNumber = number.trim();
        // 确保是纯数字且不为空
        if (cleanNumber && /^\d+$/.test(cleanNumber)) {
            if (!groupNumberToNameMap[cleanNumber]) {
                groupNumberToNameMap[cleanNumber] = [];
            }
            if (!groupNumberToNameMap[cleanNumber].includes(groupName)) {
                groupNumberToNameMap[cleanNumber].push(groupName);
            }
        }
    });
}

// 字符串相似度
function getSimilarity(s1, s2) {
    s1 = s1.toLowerCase();
    s2 = s2.toLowerCase();

    function getLevenshteinScore(a, b) {
        const len1 = a.length;
        const len2 = b.length;
        const matrix = [];
        for (let i = 0; i <= len1; i++) matrix[i] = [i];
        for (let j = 0; j <= len2; j++) matrix[0][j] = j;
        for (let i = 1; i <= len1; i++) {
            for (let j = 1; j <= len2; j++) {
                const cost = a[i - 1] === b[j - 1] ? 0 : 1;
                matrix[i][j] = Math.min(
                    matrix[i - 1][j] + 1,
                    matrix[i][j - 1] + 1,
                    matrix[i - 1][j - 1] + cost
                );
            }
        }
        const distance = matrix[len1][len2];
        return 1 - distance / Math.max(len1, len2);
    }

    function getJaccardScore(a, b) {
        const set1 = new Set(a.split(''));
        const set2 = new Set(b.split(''));
        const intersection = new Set([...set1].filter(c => set2.has(c))).size;
        const union = new Set([...set1, ...set2]).size;
        return union === 0 ? 0 : intersection / union;
    }

    return Math.max(
        getLevenshteinScore(s1, s2),
        getJaccardScore(s1, s2)
    );
}

// 合集提示（只提示存在，不暴露内容）
function getSeriesHint(groupInfo) {
    return (groupInfo.series && groupInfo.series.length > 0) ? `\n存在合集，可用 .kp se 查询` : '';
}

function findSimilarGroup(input) {
    input = input.toLowerCase();
    const matchedGroups = [];

    for (const groupName in groupMap) {
        const groupInfo = groupMap[groupName];
        let highestScore = 0;
        let matchedBy = 'name';
        let matchedItem = groupName;

        const mainScore = getSimilarity(input, groupName.toLowerCase());
        if (mainScore > highestScore) {
            highestScore = mainScore;
            matchedBy = 'name';
            matchedItem = groupName;
        }

        if (groupInfo.aliases) {
            for (const alias of groupInfo.aliases) {
                const aliasScore = getSimilarity(input, alias.toLowerCase());
                if (aliasScore > highestScore) {
                    highestScore = aliasScore;
                    matchedBy = 'alias';
                    matchedItem = alias;
                }
            }
        }

        // 兼容 series 是字符串或数组
        const seriesList = Array.isArray(groupInfo.series)
            ? groupInfo.series
            : (groupInfo.series ? [groupInfo.series] : []);

        for (const s of seriesList) {
            const seriesScore = getSimilarity(input, s.toLowerCase());
            if (seriesScore > highestScore) {
                highestScore = seriesScore;
                matchedBy = 'series';
                matchedItem = s;
            }
        }

        if (highestScore >= 0.3) {
            matchedGroups.push({
                name: groupName,
                info: groupInfo,
                score: highestScore,
                matchedBy: matchedBy,
                matchedItem: matchedItem
            });
        }
    }

    matchedGroups.sort((a, b) => b.score - a.score);
    return matchedGroups.length > 0 ? matchedGroups : null;
}

// .kp指令
const cmdKp = seal.ext.newCmdItemInfo();
cmdKp.name = 'kp';
cmdKp.help = `KP群查询指令
.kp <关键词/群号>    // 查询KP群(支持花名)
.kp se <合集关键词>  // 查询合集下的所有模组(不显示群号)
.kp list            // 群组源文件(提供镜像)
.kp list x			// 随机抽取x个群组(最多5)`;

cmdKp.solve = (ctx, msg, cmdArgs) => {
    let ret = seal.ext.newCmdExecuteResult(true);
    const input = cmdArgs.getArgN(1);

    // 命令help
    if (input === 'help' || input === '') {
        ret.showHelp = true;
        return ret;
    }

	// 通用else
	function replyNotFound(ctx, msg, input) {
    	seal.replyToSender(ctx, msg, `【${input}】查找失败，请先检查更新，或进2150284119反馈`);
	}

	// 通用花名
	function getAliasText(groupInfo) {
		if (groupInfo.aliases && groupInfo.aliases.length > 0) {
			return `(${groupInfo.aliases.join('|')})`;
		}
    	return '';
	}

	// se命令：按合集关键词查询，只显示模组名+别名+合集列表，不显示群号
    if (/^se$/i.test(input)) {
        const seKeyword = cmdArgs.getArgN(2);

        if (!seKeyword) {
            seal.replyToSender(ctx, msg, '请输入要查询的合集关键词');
            return ret;
        }

        const lowerSe = seKeyword.toLowerCase();
        const matchedEntries = [];

        for (const groupName in groupMap) {
            const groupInfo = groupMap[groupName];
            if (!groupInfo.series || groupInfo.series.length === 0) continue;

            const candidates = [groupName, ...groupInfo.series, ...(groupInfo.aliases || [])];
            let bestScore = 0;
            candidates.forEach(c => {
                if (c.toLowerCase() === lowerSe) {
                    bestScore = 1;
                } else {
                    bestScore = Math.max(bestScore, getSimilarity(seKeyword, c));
                }
            });

            if (bestScore >= 0.3) {
                matchedEntries.push({ name: groupName, info: groupInfo, score: bestScore });
            }
        }

        if (matchedEntries.length === 0) {
            seal.replyToSender(ctx, msg, `未找到【${seKeyword}】，请检查关键词`);
            return ret;
        }

        matchedEntries.sort((a, b) => b.score - a.score);

        let replyText = '';
        matchedEntries.forEach(entry => {
            const aliasText = getAliasText(entry.info);
            replyText += `【${entry.name}${aliasText}】合集\n${entry.info.series.join('\n')}\n\n`;
        });

        seal.replyToSender(ctx, msg, replyText.trim());
        return ret;
    }

    // list命令
	if (/^list/i.test(input)) {
		const countArg = cmdArgs.getArgN(2);
		
		// 无数字
		if (!countArg || isNaN(parseInt(countArg, 10))) {
            seal.replyToSender(ctx, msg, 'https://raw.githubusercontent.com/errrr-er/alll/refs/heads/main/call_of_cthulhu/kp/issues_base/database.json\n\n如果使用不了请打镜像(选其一)\n将以下内容添加在开头(不是替换！)\n\nhttps://hk.gh-proxy.org/\nhttps://gh-proxy.org/\nhttps://edgeone.gh-proxy.org/');
            return ret;
        }

        // 有数字
        let count = parseInt(countArg, 10);
        count = Math.max(1, Math.min(count, 5)); // 限制 1-5

        const allKeys = Object.keys(groupMap);
        const actualCount = Math.min(count, allKeys.length);
        const shuffled = allKeys.sort(() => Math.random() - 0.5).slice(0, actualCount);

        let replyText = `随机${actualCount}`;
        shuffled.forEach(name => {
            const info = groupMap[name];
            const aliasText = getAliasText(info);
            replyText += `\n【${name}${aliasText}】\n${info.groupNumber}\n`;
        });
        seal.replyToSender(ctx, msg, replyText);
        return ret;
    }

    // 反向查询
    if (/^\d+$/.test(input)) {
        const matchedGroups = groupNumberToNameMap[input] || [];
        
        if (matchedGroups.length > 0) {
            let replyText = ``;
            matchedGroups.forEach(groupName => {
                const groupInfo = groupMap[groupName];
			    const aliasText = getAliasText(groupInfo);
                replyText += `反向【${groupName}${aliasText}】\n${groupInfo.groupNumber}${getSeriesHint(groupInfo)}\n\n`;
            });
            seal.replyToSender(ctx, msg, replyText);
			return ret;
		}
    }
    
    // 查找匹配的群组
    let foundGroup = null;
    let exactMatch = false;
    let matchedBy = 'name';
    let matchedItem = '';

    // 1. 检查主关键词（不区分大小写）
    const lowerInput = input.toLowerCase();
    for (const groupName in groupMap) {
        if (groupName.toLowerCase() === lowerInput) {
            foundGroup = { match: { name: groupName, info: groupMap[groupName] }, score: 1 };
            exactMatch = true;
            matchedBy = 'name';
            matchedItem = groupName;
            break;
        }
    }

    // 2. 检查所有群组的别名（不区分大小写）
    if (!foundGroup) {
        for (const groupName in groupMap) {
            const groupInfo = groupMap[groupName];
            if (groupInfo.aliases) {
                for (const alias of groupInfo.aliases) {
                    if (alias.toLowerCase() === lowerInput) {
                        foundGroup = { match: { name: groupName, info: groupInfo }, score: 1 };
                        exactMatch = true;
                        matchedBy = 'alias';
                        matchedItem = alias;
                        break;
                    }
                }
            }
            if (exactMatch) break;
        }
    }

    // 3. 检查所有群组的 series（不区分大小写，兼容字符串/数组）
    if (!foundGroup) {
        for (const groupName in groupMap) {
            const groupInfo = groupMap[groupName];
            const seriesList = Array.isArray(groupInfo.series)
                ? groupInfo.series
                : (groupInfo.series ? [groupInfo.series] : []);
            for (const s of seriesList) {
                if (s.toLowerCase() === lowerInput) {
                    foundGroup = { match: { name: groupName, info: groupInfo }, score: 1 };
                    exactMatch = true;
                    matchedBy = 'series';
                    matchedItem = s;
                    break;
                }
            }
            if (exactMatch) break;
        }
    }

    // 4. 如果没有精确匹配，尝试近似匹配
    if (!foundGroup) {
        const matchedGroups = findSimilarGroup(input);
        if (matchedGroups) {
            const chunkSize = 5; // 每段显示x个结果
            const chunks = [];
            for (let i = 0; i < matchedGroups.length; i += chunkSize) {
                chunks.push(matchedGroups.slice(i, i + chunkSize));
            }
            // 分段发送
            const sendChunk = (index) => {
                if (index >= chunks.length) return;
                const chunk = chunks[index];
                let replyText = chunks.length > 1
                    ? `近似【${input}】（${index + 1}/${chunks.length}）`
                    : `近似【${input}】`;

                chunk.forEach(group => {
                    const aliasText = getAliasText(group.info);
                    const seriesHint = getSeriesHint(group.info);
                    const viaSeries = group.matchedBy === 'series'
                        ? `（合集子模组「${group.matchedItem}」所属）`
                        : '';
                    replyText += `\n【${group.name}${aliasText}】${viaSeries}${Math.round(group.score * 100)}%\n${group.info.groupNumber}\n${seriesHint}\n`;
                });
                seal.replyToSender(ctx, msg, replyText);
                setTimeout(() => sendChunk(index + 1), 3000);  // x秒后发下一段
            };
            sendChunk(0);  // 开始发送第一段
        } else {
            replyNotFound(ctx, msg, input);
        }
    } else {
        // 精确匹配输出
        const aliasText = getAliasText(foundGroup.match.info);
        const seriesHint = getSeriesHint(foundGroup.match.info);
        const viaSeries = matchedBy === 'series'
            ? `（合集子模组「${matchedItem}」所属）`
            : '';
        seal.replyToSender(ctx, msg, `精确【${foundGroup.match.name}${aliasText}】${viaSeries}\n${foundGroup.match.info.groupNumber}\n${seriesHint}`);
    }

    return ret;
};

// 注册指令
ext.cmdMap['kp'] = cmdKp;
