// ==UserScript==
// @name         测试
// @author       3987681449
// @version      0.0.0
// @description  回头这边记得全改掉
// @timestamp    1779337518
// 2026-05-21 04:25:18
// @license      Apache-2
// @homepageURL  https://github.com/errrr-er/alll/tree/main
// ==/UserScript==

let ext = seal.ext.find('只是测试');
if (!ext) {
  ext = seal.ext.new('只是测试', 'er', '1.0.11');
  seal.ext.register(ext);
}

// 辅助函数
function getExportText(ctx) {
  let varName = `$m跑团记录_${ctx.group.groupId}_${ctx.player.userId}`;
  let records = seal.vars.strGet(ctx, varName)[0] || '';
  let lines = records.trim().split('\n').filter(l => l.trim());

  if (lines.length === 0) return '暂无记录';

  let stats = {};
  let rawLines = [];

  lines.forEach(line => {
    let match = line.match(/^(.+?)：(.+?) \(D100=(\d+)\/(\d+)\)$/);
    if (match) {
      let skill = match[1];
      let level = match[2];
      let key = `${skill}::${level}`;
      stats[key] = (stats[key] || 0) + 1;
    } else {
      rawLines.push(line);
    }
  });

  let skillMap = {};
  for (let [key, count] of Object.entries(stats)) {
    let [skill, level] = key.split('::');
    if (!skillMap[skill]) skillMap[skill] = [];
    skillMap[skill].push({ level, count });
  }

  let outputLines = [];
  for (let skill of Object.keys(skillMap).sort()) {
    let parts = skillMap[skill].map(item => {
      return item.count > 1 ? `${item.level}×${item.count}` : item.level;
    });
    outputLines.push(`${skill}：${parts.join('，')}`);
  }

  if (rawLines.length > 0) {
    outputLines.push('');
    outputLines.push('以下记录格式异常，已保留原始内容：');
    outputLines = outputLines.concat(rawLines);
  }

  let playerName = ctx.player.name || '未知玩家';
  let totalThrows = lines.length;
  return `【${playerName}】 共 ${totalThrows} 次投掷\n` + outputLines.join('\n');
}

// 监听发送的消息
ext.onMessageSend = (ctx, msg, flag) => {
  if (!ctx.group) return;
  if (!ctx.group.logOn) return;

  let messageText = msg.message || '';

  let skillName = '';
  let diceResult = '';
  let skillValue = '';
  let successLevel = '';

  // 先尝试匹配 SC
  let scMatch = messageText.match(/的理智检定:\s*[dD]100=(\d+)\/(\d+)\s*(.+)/);
  if (scMatch) {
    skillName = 'SC';
    diceResult = scMatch[1];
    skillValue = scMatch[2];
    successLevel = scMatch[3].trim().replace(/[！!]/g, '');
  } else {
    // 再尝试匹配 RA
    let raMatch = messageText.match(/"([^"]+)"检定结果为:\s*D100=(\d+)\/(\d+)\s*(.+)/);
    if (raMatch) {
      skillName = raMatch[1].replace(/\d+$/, '');
      if (!skillName) skillName = '检定';
      diceResult = raMatch[2];
      skillValue = raMatch[3];
      successLevel = raMatch[4].trim().replace(/[！!]/g, '');
    }
  }

  if (!skillName) return;

  let record = `${skillName}：${successLevel} (D100=${diceResult}/${skillValue})`;

  let varName = `$m跑团记录_${ctx.group.groupId}_${ctx.player.userId}`;
  let old = seal.vars.strGet(ctx, varName)[0] || '';
  seal.vars.strSet(ctx, varName, old + '\n' + record);
};

// 监听指令
ext.onCommandReceived = (ctx, msg, cmdArgs) => {
  if (!ctx.group) return;

  let cmd = cmdArgs.command.toLowerCase();
  if (cmd !== 'log') return;

  let sub = cmdArgs.getArgN(1);

  if (sub === 'new') {
    let varName = `$m跑团记录_${ctx.group.groupId}_${ctx.player.userId}`;
    seal.vars.strSet(ctx, varName, '');
  }

  if (sub === 'end') {
    let exportText = getExportText(ctx);
    if (exportText !== '暂无记录') {
      seal.replyToSender(ctx, msg, `记录已自动导出：\n${exportText}`);
      let varName = `$m跑团记录_${ctx.group.groupId}_${ctx.player.userId}`;
      seal.vars.strSet(ctx, varName, '');
    }
  }
};

// countlog 指令
const cmdCountlog = seal.ext.newCmdItemInfo();
cmdCountlog.name = 'countlog';
cmdCountlog.help = '用法：\n.countlog st → 导出记录\n.countlog clr → 导出并清除记录';
cmdCountlog.solve = (ctx, msg, cmdArgs) => {
  if (!ctx.group) {
    seal.replyToSender(ctx, msg, '请在群内使用此指令');
    return seal.ext.newCmdExecuteResult(true);
  }

  let sub = cmdArgs.getArgN(1);

  if (sub === 'st') {
    let output = getExportText(ctx);
    seal.replyToSender(ctx, msg, output);
    return seal.ext.newCmdExecuteResult(true);
  }

  if (sub === 'clr') {
    let output = getExportText(ctx);
    let playerName = ctx.player.name || '未知玩家';
    if (output !== '暂无记录') {
      seal.replyToSender(ctx, msg, `${playerName}的记录导出如下：\n${output}\n\n记录已清除`);
    } else {
      seal.replyToSender(ctx, msg, `${playerName}本来就没有内容，无需清除`);
    }
    let varName = `$m跑团记录_${ctx.group.groupId}_${ctx.player.userId}`;
    seal.vars.strSet(ctx, varName, '');
    return seal.ext.newCmdExecuteResult(true);
  }

  seal.replyToSender(ctx, msg, '用法：\n.countlog st → 导出记录\n.countlog clr → 导出并清除记录');
  return seal.ext.newCmdExecuteResult(true);
};
ext.cmdMap['countlog'] = cmdCountlog;